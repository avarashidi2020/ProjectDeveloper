package app.baseurl;

public class BaseUrl {


  public static String geturl() {

    return "https://avarashidi.ir/newProject/";
  }

}
